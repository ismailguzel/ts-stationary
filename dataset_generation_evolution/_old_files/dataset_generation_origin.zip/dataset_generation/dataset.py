
import random
from dataset_generator import (
    generate_linear_trend_dataset,
    generate_quadratic_trend_dataset,
    generate_cubic_trend_dataset,
    generate_exponential_trend_dataset,
    generate_damped_trend_dataset,
    generate_point_anomaly_dataset,
    generate_collective_anomaly_dataset,
    generate_contextual_anomaly_dataset,
    generate_wn_dataset,
    generate_ar_dataset,
    generate_ma_dataset,
    generate_arma_dataset,
    generate_random_walk_dataset,
    generate_random_walk_with_drift_dataset,
    generate_ari_dataset,
    generate_ima_dataset,
    generate_arima_dataset,
    generate_aparch_dataset,
    generate_arch_dataset,
    generate_egarch_dataset,
    generate_garch_dataset,
    generate_single_seasonality_dataset,
    generate_multiple_seasonality_dataset,
    generate_sarma_dataset,
    generate_sarima_dataset,
    generate_mean_shift_dataset,
    generate_variance_shift_dataset,
    generate_trend_shift_dataset
)



bases = ["ar", "ma", "arma", "white_noise"]
length_ranges = [(50, 100), (300, 500), (1000, 10000)]
signs = [1, -1]
locations = ["beginning", "middle", "end"] 

#### STATIONARY SERIES

for base in bases:
    for length_range in length_ranges:
        
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        
        if base == "ar":
            generate_ar_dataset(folder=f"stationary/{base}/{l}", count=10, length_range=length_range)
        elif base == "ma":
            generate_ma_dataset(folder=f"stationary/{base}/{l}", count=10, length_range=length_range)
        elif base == "arma":
            generate_arma_dataset(folder=f"stationary/{base}/{l}", count=10, length_range=length_range)
        elif base == "white_noise":
            generate_wn_dataset(folder=f"stationary/{base}/{l}", count=10, length_range=length_range)




######linear trend
for base in bases:
    for length_range in length_ranges:
        for sign in signs:
            d = "up" if sign == 1 else "down"
            if length_range == (50,100):
              l = "short"
            elif length_range == (300,500):
              l = "medium"
            else:
              l = "long"

            generate_linear_trend_dataset(
                folder=f"deterministic_trend_linear/{d}/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                sign=sign
            )

######quadratic trend
for base in bases:
    for length_range in length_ranges:
        for sign in signs:
            d = "up" if sign == 1 else "down"
            if length_range == (50,100):
              l = "short"
            elif length_range == (300,500):
              l = "medium"
            else:
              l = "long"

            generate_quadratic_trend_dataset(
                folder=f"deterministic_trend_quadratic/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                sign=sign
            )


#######cubic trend
for base in bases:
    for length_range in length_ranges:
        for sign in signs:
            d = "up" if sign == 1 else "down"
            if length_range == (50,100):
              l = "short"
            elif length_range == (300,500):
              l = "medium"
            else:
              l = "long"

            generate_cubic_trend_dataset(
                folder=f"deterministic_trend_cubic/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                sign=sign
            )




########exponential trend
for base in bases:
    for length_range in length_ranges:
        for sign in signs:
            d = "up" if sign == 1 else "down"
            if length_range == (50,100):
              l = "short"
            elif length_range == (300,500):
              l = "medium"
            else:
              l = "long"

            generate_exponential_trend_dataset(
                folder=f"deterministic_trend_exponential/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                sign=sign
            )




#######damped trend
for base in bases:
    for length_range in length_ranges:
        for sign in signs:
            d = "up" if sign == 1 else "down"
            if length_range == (50,100):
              l = "short"
            elif length_range == (300,500):
              l = "medium"
            else:
              l = "long"

            generate_damped_trend_dataset(
                folder=f"deterministic_trend_damped/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                sign=sign
            )



#######point anomaly
#single point anomalies
for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for loc in locations:
            generate_point_anomaly_dataset(
                folder=f"point_anomaly_single/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                anomaly_type='single',
                location=loc
            )

#multi point anomalies
for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        generate_point_anomaly_dataset(
            folder=f"point_anomaly_multiple/{base}/{l}",
            kind=base,
            count=10,
            length_range=length_range,
            anomaly_type='multiple'
        )




######collective anomaly
for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for loc in locations:
            generate_collective_anomaly_dataset(
                folder=f"collective_anomaly/{base}/{l}",
                kind=base,
                count=10,
                length_range=length_range,
                location=loc
            )


for base in bases:
    for length_range in [(1000, 10000)]:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        n = random.randint(2,4)
        generate_collective_anomaly_dataset(
        folder=f"multi_collective_anomaly/{base}/{l}",
            kind=base,
            count=10,
            num_anomalies=n,
            anomaly_type='multiple',
            length_range=length_range,
        )



#####contextual anomaly
for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for loc in locations:
            generate_contextual_anomaly_dataset(
                folder=f"contextual_anomaly/{base}/{l}",
                count=10,
                length_range=length_range,
                location=loc
            )


for base in bases:
    for length_range in [(1000, 10000)]:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        n = random.randint(2,4)
        generate_contextual_anomaly_dataset(
        folder=f"multi_contextual_anomaly/{base}/{l}",
            count=10,
            num_anomalies=n,
            anomaly_type='multiple',
            length_range=length_range,
        )



#### STOCHASTIC SERIES ####

stochastic_bases = ["random_walk", "random_walk_drift", "ari", "ima", "arima"]

for base in stochastic_bases:
    for length_range in length_ranges:

        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"

        if base == "random_walk":
            generate_random_walk_dataset(folder=f"stochastic/{base}/{l}", count=10, length_range=length_range)
        elif base == "random_walk_drift":
            generate_random_walk_with_drift_dataset(folder=f"stochastic/{base}/{l}", count=10, length_range=length_range)
        elif base == "ari":
            generate_ari_dataset(folder=f"stochastic/{base}/{l}", count=10, length_range=length_range)
        elif base == "ima":
            generate_ima_dataset(folder=f"stochastic/{base}/{l}", count=10, length_range=length_range)
        elif base == "arima":
            generate_arima_dataset(folder=f"stochastic/{base}/{l}", count=10, length_range=length_range)

#### VOLATILITY SERIES ####

volatility_bases = ["arch", "garch", "egarch", "aparch"]

for base in volatility_bases:
    for length_range in length_ranges:

        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"

        if base == "arch":
            generate_arch_dataset(folder=f"volatility/{base}/{l}", count=10, length_range=length_range)
        elif base == "garch":
            generate_garch_dataset(folder=f"volatility/{base}/{l}", count=10, length_range=length_range)
        elif base == "egarch":
            generate_egarch_dataset(folder=f"volatility/{base}/{l}", count=10, length_range=length_range)
        elif base == "aparch":
            generate_aparch_dataset(folder=f"volatility/{base}/{l}", count=10, length_range=length_range)



###### seasonality ######

seasonality_types = ['single', 'multiple', 'sarma', 'sarima']

for seasonality in seasonality_types:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"

        if seasonality == 'single':
            generate_single_seasonality_dataset(folder=f"single_seasonality/{l}", count = 10, length_range=length_range)
        if seasonality == 'multiple':
            #n = random.randint(2,3)
            generate_multiple_seasonality_dataset(folder=f"multiple_seasonality/{l}", count = 10, length_range=length_range)
        if seasonality == 'sarma':
            if l == 'long':
                pass
            else:
                generate_sarma_dataset(folder=f"sarma_seasonality/{l}", count = 10, length_range=length_range)
        if seasonality == 'sarima':
            if l == 'long':
                pass
            else:
                generate_sarma_dataset(folder=f"sarima_seasonality/{l}", count = 10, length_range=length_range)



###### structural breaks ######

### mean shift ###

for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for loc in locations:
            for sign in signs:
                generate_mean_shift_dataset(
                    folder=f"mean_shift/{base}/{l}",
                    kind=base,
                    count=10,
                    signs = [sign],
                    length_range=length_range,
                    location=loc,
                    break_type = 'single',
                    num_breaks = 1)


for base in bases:
    for length_range in [(300,500), (1000, 10000)]:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        n = random.randint(2,4)
        generate_mean_shift_dataset(
        folder=f"multi_mean_shift/{base}/{l}",
            kind=base,
            count=10,
            num_breaks=n,
            break_type='multiple',
            length_range=length_range)
        

### variance shift ###

for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for loc in locations:
            for sign in signs:
                generate_variance_shift_dataset(
                    folder=f"variance_shift/{base}/{l}",
                    kind=base,
                    count=10,
                    signs = [sign],
                    length_range=length_range,
                    location=loc,
                    break_type = 'single',
                    num_breaks = 1)


for base in bases:
    for length_range in [(300,500), (1000, 10000)]:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        n = random.randint(2,4)
        generate_variance_shift_dataset(
        folder=f"multi_variance_shift/{base}/{l}",
            kind=base,
            count=10,
            num_breaks=n,
            break_type='multiple',
            length_range=length_range)


### trend shift ###

change_types = ['direction_change', 'magnitude_change', 'direction_and_magnitude_change'] 

for base in bases:
    for length_range in length_ranges:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for loc in locations:
            for sign in signs:
                for change_type in change_types:
                    generate_trend_shift_dataset(
                        folder=f"trend_shift/{base}/{l}",
                        kind=base,
                        count=10,
                        sign = sign,
                        change_types = [change_type],
                        length_range=length_range,
                        location=loc,
                        break_type = 'single',
                        num_breaks = 1)


for base in bases:
    for length_range in [(300,500), (1000, 10000)]:
        if length_range == (50,100):
            l = "short"
        elif length_range == (300,500):
            l = "medium"
        else:
            l = "long"
        for sign in signs:
            n = random.randint(2,4)
            change_types = random.choices(change_types, k=n)
            generate_trend_shift_dataset(
            folder=f"multi_trend_shift/{base}/{l}",
                kind=base,
                count=10,
                num_breaks=n,
                change_types = change_types, 
                sign = sign,
                break_type='multiple',
                length_range=length_range)

